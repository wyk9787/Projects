# Skip List

## Files

### SkipList.java

Contains the implementation of SkipList

### SkipListNode.java

Contains the implementation of SkipListNode

### SkipListTest.java

Contains the test for the SkipList

## Usage 

* Import all three files in to a project in eclipse and configure the project.  
* Click run in the SkipListTest.java to run the test